KMPDinoEthernet
===============
This library support our ProDiNo NetBoard V2.1 hardware.
For more information see here: http://www.kmpelectronics.eu/en-us/products/prodinoethernet.aspx
