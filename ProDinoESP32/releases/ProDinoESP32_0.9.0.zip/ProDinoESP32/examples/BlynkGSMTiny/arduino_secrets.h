 // You have to get your Authentication Token through Blynk Application.
 const char AUTH_TOKEN[] = "123456789012345678901234567890123";

 // SIM card pin number if exists
 const char PINNUMBER[] = "";
 // replace your GPRS APN
 const char GPRS_APN[] = "xxxx"; 
 // replace with your GPRS login
 const char GPRS_LOGIN[] = "xxxx";
 // replace with your GPRS password
 const char GPRS_PASSWORD[] = "xxxx";