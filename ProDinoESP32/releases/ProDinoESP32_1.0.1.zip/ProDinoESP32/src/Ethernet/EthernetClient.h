// This file is in the public domain.  No copyright is claimed.

#include <Arduino.h>

#include "Ethernet.h"
#include "Dns.h"
#include "utility/w5100.h"