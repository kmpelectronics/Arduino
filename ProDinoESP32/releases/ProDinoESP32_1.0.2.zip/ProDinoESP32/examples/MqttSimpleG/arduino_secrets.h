// SIM card pin number if exists
#define SECRET_PINNUMBER     ""
#define SECRET_GPRS_APN      "" // replace your GPRS APN
#define SECRET_GPRS_LOGIN    "" // replace with your GPRS login
#define SECRET_GPRS_PASSWORD "" // replace with your GPRS password

// MQTT server settings. 
#define MQTT_SERVER           "" 	// Change it with yours data.
#define MQTT_PORT             12345 // Change it with yours data.
#define MQTT_USER             "" 	// Change it with yours data.
#define MQTT_PASS             "" 	// Change it with yours data.