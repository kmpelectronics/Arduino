// You have to get your Authentication Token through Blynk Application.
#define AUTH_TOKEN "1234567890abcdef1234567890ABCDEF"

// Your WiFi credentials
#define SSID_NAME ""
#define SSID_PASSWORD ""

// SIM card pin number if exists
#define SECRET_PINNUMBER     ""
#define SECRET_GPRS_APN      "" // replace your GPRS APN
#define SECRET_GPRS_LOGIN    ""    // replace with your GPRS login
#define SECRET_GPRS_PASSWORD "" // replace with your GPRS password