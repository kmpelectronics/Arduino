// You have to get your Authentication Token through Blynk Application.
#define AUTH_TOKEN "1234567890abcdef1234567890ABCDEF"

// Your WiFi credentials
#define SSID_NAME ""
#define SSID_PASSWORD ""