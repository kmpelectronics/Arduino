const char SSID[] = "";
const char SSID_PASSWORD[] = "";
// MQTT server settings. 
#define MQTT_SERVER  "xxx.cloudmqtt.com" // Change it with yours data.
#define MQTT_PORT    12345 // Change it with yours data.
#define MQTT_USER    "xxxxx" // Change it with yours data.
#define MQTT_PASS    "xxxxx" // Change it with yours data.