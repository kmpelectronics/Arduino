#define SECRET_PINNUMBER     ""
#define SECRET_GPRS_APN      "" // replace your GPRS APN
#define SECRET_GPRS_LOGIN    ""    // replace with your GPRS login
#define SECRET_GPRS_PASSWORD "" // replace with your GPRS password
