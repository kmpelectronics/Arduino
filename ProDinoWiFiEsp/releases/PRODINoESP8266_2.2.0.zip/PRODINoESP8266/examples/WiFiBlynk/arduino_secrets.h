// You have to get your Authentication Token through Blynk Application.
#define AUTH_TOKEN ""

// Your WiFi credentials
#define SSID_NAME ""
#define SSID_PASSWORD ""