// WiFi settings
#define SSID				""
#define SSID_PASSWORD		""

// MQTT server settings. 
#define MQTT_SERVER         "xxx.cloudmqtt.com" // Change it with yours data.
#define MQTT_PORT           12345 // Change it with yours data.
#define MQTT_USER           "" // Change it with yours data.
#define MQTT_PASS           "" // Change it with yours data.