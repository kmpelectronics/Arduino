// Your WiFi credentials
#define SSID_NAME ""
#define SSID_PASSWORD ""